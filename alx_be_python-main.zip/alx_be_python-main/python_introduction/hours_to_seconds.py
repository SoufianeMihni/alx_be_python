hours = 2 

seconds = 3600 * hours

print(f"2 hour(s) is {seconds} seconds.")