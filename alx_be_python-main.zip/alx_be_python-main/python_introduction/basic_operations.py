number1 = 10
number2 = 5

Addition = number1 + number2
Subtraction = number1 - number2
Multiplication = number1 * number2

print(f"Addition of", Addition)
print(f"Subtraction of", Addition)
print(f"Multiplication of", Addition)