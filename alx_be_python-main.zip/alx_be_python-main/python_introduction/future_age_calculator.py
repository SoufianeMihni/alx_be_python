age = int(input("How old are you?"))

age_in_2050 = age + 27
print(f"In 2050, you will be {age_in_2050} years old.")